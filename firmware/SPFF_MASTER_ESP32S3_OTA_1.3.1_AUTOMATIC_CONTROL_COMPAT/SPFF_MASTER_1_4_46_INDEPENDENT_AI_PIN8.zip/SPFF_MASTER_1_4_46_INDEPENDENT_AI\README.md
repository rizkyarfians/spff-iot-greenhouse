# SPFF 1.4.46 INDEPENDENT AI — SOIL PIN 8x

Paket sumber untuk ESP32-S3 Master (Waveshare ESP32-S3-ETH-8DI-8RO).

Basis: 1.4.45. Perubahan tunggal: burst percobaan untuk field tanah yang sudah
tua dinaikkan dari 5 menjadi **8 percobaan**, dan jeda antar percobaan
dipendekkan dari 120 ms menjadi **80 ms**. Dengan peluang lolos per frame
sekitar 25–35%, satu burst kini menyelesaikan field tertinggal dengan peluang
±90%. Logika pompa, interlock air, jadwal, OTA, dan protokol ke Orange Pi
tidak berubah.

## Riwayat versi sensor tanah (28 Oktober 2026)

| Versi | Perubahan | Field valid | Umur maks | Umur rata-rata |
|---|---|---|---|---|
| 1.4.36 | slot 1500 ms | 8–13 / 14 | 300–600 s | 100–200 s |
| 1.4.42 | retry 3x per slot | setara 1.4.36 | — | — |
| 1.4.43 | + settle 1,5 ms + 8N2 | **0 / 14** (8N2 merusak) | — | — |
| 1.4.44 | slot 150 ms | 13–14 / 14 | 294 s | 46–120 s |
| 1.4.45 | pinned retry 5x | 12–14 / 14 | 340 s | 40–120 s |
| **1.4.46** | **pinned retry 8x, gap 80 ms** | **12–13 / 14** | **77–133 s** | **29–61 s** |

Catatan jujur: akar masalah bus RS485 belum terselesaikan dan kemungkinan besar
bersifat fisik (tegangan suplai sensor, alamat Modbus kembar, atau
kabel/terminasi). Versi ini memaksimalkan peluang mendapat frame valid, bukan
menyembuhkan penyebabnya. Satu field, `soil_2_ph`, masih tercatat 0 sukses dari
18 percobaan pada pengujian terakhir — kemungkinan register tersebut memang
bermasalah di unit sensor 2.

## Isi paket

```
SPFF_MASTER_1_4_46_INDEPENDENT_AI_PIN8.ino   sketch utama
SpffBuildCheck.h                             guard profil build
PulseDeadline.h                              header pulse server
ServerSoilEcPulse.h                          header pulse EC tanah
IndependentScheduleOutput.h                  header output jadwal
BUILD_PROFILE.json                           profil build
PANDUAN.md                                   panduan operasional
VERIFICATION.json                            bukti build
SHA256SUMS.txt                               checksum
binary/*.bin                                 firmware aplikasi (offset 0x10000)
binary/*.elf                                 ELF untuk debug
```

## Profil build

- Core `esp32:esp32@2.0.17`
- FQBN `esp32:esp32:esp32s3:FlashMode=qio,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB,USBMode=hwcdc,CDCOnBoot=cdc`
- Library: `Ethernet` 2.0.2, `LiquidCrystal_I2C`, `ArduinoJson`

## Upload

Arduino IDE: buka folder ini (nama folder harus sama dengan nama `.ino`),
pilih ESP32S3 Dev Module dengan pengaturan di atas, lalu Upload.

Lewat Orange Pi (aplikasi saja, 0x10000, jangan 0x0):

```bash
sudo systemctl stop spff-edge-gateway
sudo /home/orangepi/esptool-venv/bin/python -m esptool --chip esp32s3 \
  --port /dev/ttyACM0 --baud 115200 write-flash 0x10000 \
  binary/SPFF_MASTER_1_4_46_INDEPENDENT_AI_PIN8.ino.bin
sudo systemctl start spff-edge-gateway
```

Pastikan kedua pompa OFF secara fisik sebelum upload. Jangan erase-flash.
