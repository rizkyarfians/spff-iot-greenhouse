# SPFF 1.4.50 INDEPENDENT AI — SOIL AUTO-HEAL

Paket sumber untuk ESP32-S3 Master (Waveshare ESP32-S3-ETH-8DI-8RO).

Basis: 1.4.46 (konfigurasi terbaik hasil pengujian 1.4.44–1.4.49).

Perubahan tunggal: **watchdog penyembuhan otomatis**. Kalau salah satu sensor
tanah tidak menghasilkan frame valid selama 180 detik, UART RS485 dibongkar
dan diinisialisasi ulang (9600 lalu 4800) sehingga buffer RX ikut dibuang,
paling sering sekali per 60 detik. Ini membersihkan kondisi baud yang
desinkron atau sensor yang berhenti menjawab, **tanpa restart ESP32** dan
tanpa menyentuh logika pompa.

## Mengapa perlu

Pengamatan lapangan: pembacaan "bisa, lalu setelah beberapa waktu tidak bisa
lagi". Itu pola degradasi, bukan acak. Dua penyebab yang paling mungkin:

1. status `activeBaud` di firmware tidak lagi sama dengan baud hardware
   sebenarnya setelah rantai ganti baud 9600 ↔ 4800;
2. sensor berhenti menjawab sampai di-reset.

Sebelumnya keduanya hanya bisa dipulihkan dengan me-reboot ESP32. Sekarang
dipulihkan otomatis di dalam firmware.

## Hasil uji (28 Oktober 2026)

| Versi | Perubahan | Field valid | Umur maks | Sukses/frame |
|---|---|---|---|---|
| 1.4.44 | slot 150 ms | 13–14 | 294 s | 25% |
| 1.4.45 | pin 5x | 12–14 | 340 s | 28% |
| 1.4.46 | pin 8x, gap 80 ms | 13 | 77–163 s | 36% |
| 1.4.47 | tanpa ganti baud, slot 80 ms | 7–9 | 289 s | 7% |
| 1.4.48 | + timeout 260 ms | 6–8 | 309 s | 6% |
| 1.4.49 | + pilih sensor tertua | 11–13 | 308 s | 20% |
| **1.4.50** | **auto-heal dari 1.4.46** | **13–14** | 150–380 s lalu pulih | 25% |

Catatan penting dari 1.4.50: `soil_2_ph` yang sebelumnya **0 sukses dari 18
percobaan** kini kembali menghasilkan data (3 sukses). Itu bukti watchdog
berhasil menghidupkan kembali jalur yang macet.

Pelajaran dari versi yang gagal:

- 1.4.47: menghapus jeda ganti baud membuat bus tidak pernah tenang → sukses
  jatuh ke 7%. Ganti baud 9600 setiap slot ternyata berfungsi sebagai jeda.
- 1.4.48: timeout 260 ms terlalu pendek; sebagian balasan sensor datang lebih
  lambat dari itu.
- 1.4.49: selalu melayani sensor yang paling tua membuat sensor lain
  kelaparan; rotasi bergantian lebih adil.

## Batas yang perlu diketahui

Hanya ±25–36% frame yang lolos CRC. Penyebabnya fisik: tegangan suplai sensor
(24 V terhadap spek yang mungkin 5–12 V), kemungkinan alamat Modbus kembar,
serta kabel/terminasi/ground. Firmware sudah di titik optimal; untuk 14/14
field yang benar-benar segar, jalur fisik harus diperbaiki.

## Isi paket

```
SPFF_MASTER_1_4_50_INDEPENDENT_AI_AUTOHEAL.ino   sketch utama
SpffBuildCheck.h                                 guard profil build
PulseDeadline.h                                  header pulse server
ServerSoilEcPulse.h                              header pulse EC tanah
IndependentScheduleOutput.h                      header output jadwal
BUILD_PROFILE.json                               profil build
PANDUAN.md                                       panduan operasional
VERIFICATION.json                                bukti build
SHA256SUMS.txt                                   checksum
binary/*.bin                                     firmware aplikasi (offset 0x10000)
binary/*.elf                                     ELF untuk debug
```

## Profil build

- Core `esp32:esp32@2.0.17`
- FQBN `esp32:esp32:esp32s3:FlashMode=qio,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB,USBMode=hwcdc,CDCOnBoot=cdc`
- Library: `Ethernet` 2.0.2, `LiquidCrystal_I2C`, `ArduinoJson`

## Upload

Arduino IDE: buka folder ini (nama folder harus sama dengan `.ino`), pilih
ESP32S3 Dev Module dengan pengaturan di atas, lalu Upload.

Lewat Orange Pi (aplikasi saja, 0x10000, jangan 0x0):

```bash
sudo systemctl stop spff-edge-gateway
sudo /home/orangepi/esptool-venv/bin/python -m esptool --chip esp32s3 \
  --port /dev/ttyACM0 --baud 115200 write-flash 0x10000 \
  binary/SPFF_MASTER_1_4_50_INDEPENDENT_AI_AUTOHEAL.ino.bin
sudo systemctl start spff-edge-gateway
```

Pastikan kedua pompa OFF secara fisik sebelum upload. Jangan erase-flash.
