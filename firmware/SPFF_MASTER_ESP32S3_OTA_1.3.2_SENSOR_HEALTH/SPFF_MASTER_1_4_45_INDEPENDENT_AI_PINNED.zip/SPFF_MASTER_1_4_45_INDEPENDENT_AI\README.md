# SPFF 1.4.45 INDEPENDENT AI — SOIL PINNED RETRY

Paket sumber untuk ESP32-S3 Master (Waveshare ESP32-S3-ETH-8DI-8RO).

Basis: 1.4.44. Perubahan tunggal: kalau salah satu field tanah pada sebuah
sensor masih lebih tua dari 120 detik, slot itu memberi **5 percobaan
beruntun** (jeda 120 ms) ke sensor tersebut, bukan sekali tembak. Karena
`readSoil()` selalu memilih register paling tua, percobaan beruntun otomatis
terus mengenai field yang tertinggal.

Logika pompa, interlock air, jadwal, OTA, dan protokol ke Orange Pi tidak
berubah.

## Riwayat versi sensor tanah (28 Oktober 2026)

| Versi | Perubahan | Field valid | Umur data rata-rata |
|---|---|---|---|
| 1.4.36 | slot 1500 ms | 8–13 / 14 | 100–200 detik |
| 1.4.42 | retry 3x per slot | setara 1.4.36 | — |
| 1.4.43 | + settle 1,5 ms + 8N2 | **0 / 14** (8N2 merusak) | — |
| 1.4.44 | slot 150 ms | 13–14 / 14 | 46–120 detik |
| **1.4.45** | **pinned retry 5x** | **12–14 / 14** | **40–110 detik**, maksimum 2–5 menit |

Catatan jujur: akar masalah bus RS485 (frame sering korup, hanya ±25% lolos
CRC) belum terselesaikan dan kemungkinan besar bersifat fisik — tegangan
suplai sensor, alamat Modbus kembar, atau kabel/terminasi. Versi ini
memaksimalkan peluang mendapat frame valid, bukan menyembuhkan penyebabnya.

## Isi paket

```
SPFF_MASTER_1_4_45_INDEPENDENT_AI_PINNED.ino   sketch utama
SpffBuildCheck.h                               guard profil build
PulseDeadline.h                                header pulse server
ServerSoilEcPulse.h                            header pulse EC tanah
IndependentScheduleOutput.h                    header output jadwal
BUILD_PROFILE.json                             profil build
PANDUAN.md                                     panduan operasional
VERIFICATION.json                              bukti build
SHA256SUMS.txt                                 checksum
binary/*.bin                                   firmware aplikasi (offset 0x10000)
binary/*.elf                                   ELF untuk debug
```

## Profil build

- Core `esp32:esp32@2.0.17`
- FQBN `esp32:esp32:esp32s3:FlashMode=qio,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB,USBMode=hwcdc,CDCOnBoot=cdc`
- Library: `Ethernet` 2.0.2, `LiquidCrystal_I2C`, `ArduinoJson`

## Upload

Arduino IDE: buka folder ini (nama folder harus sama dengan nama `.ino`),
pilih ESP32S3 Dev Module dengan pengaturan di atas, lalu Upload.

Lewat Orange Pi (aplikasi saja, 0x10000, jangan 0x0):

```bash
sudo systemctl stop spff-edge-gateway
sudo /home/orangepi/esptool-venv/bin/python -m esptool --chip esp32s3 \
  --port /dev/ttyACM0 --baud 115200 write-flash 0x10000 \
  binary/SPFF_MASTER_1_4_45_INDEPENDENT_AI_PINNED.ino.bin
sudo systemctl start spff-edge-gateway
```

Pastikan kedua pompa OFF secara fisik sebelum upload. Jangan erase-flash.
